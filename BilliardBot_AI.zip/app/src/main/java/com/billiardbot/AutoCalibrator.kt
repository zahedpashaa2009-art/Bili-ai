package com.billiardbot

import com.billiardbot.ai.AutoCal

/** Runs the geometric auto-calibration, then lets the real ball detector pick the ball size that gives the most plausible table. */
object AutoCalibrator {
    fun run(f: Frame, cal: Calib): AutoCal.Result {
        val res = AutoCal.run(f.px, f.w, f.h, f.stride)
        if (!res.ok) return res
        cal.l = res.l; cal.t = res.t; cal.r = res.r; cal.b = res.b; cal.ball = res.ball
        if (res.powerFound) { cal.pTopX = res.ptx; cal.pTopY = res.pty; cal.pBotX = res.pbx; cal.pBotY = res.pby }
        var bestR = res.ball
        var bestS = score(Vision.detect(f, cal))
        for (k in floatArrayOf(-0.03f, 0.03f, -0.06f, 0.06f)) {
            cal.ball = res.ball * (1f + k)
            val s = score(Vision.detect(f, cal))
            if (s > bestS) { bestS = s; bestR = cal.ball }
        }
        cal.ball = bestR
        res.ball = bestR
        cal.save()
        return res
    }

    /** A plausible rack: ~1 cue ball, at most one 8, at most 7 solids and 7 stripes, as many balls as possible. */
    private fun score(b: List<Ball>): Float {
        if (b.isEmpty()) return 0f
        var s = minOf(b.size, 16).toFloat()
        val cue = b.count { it.kind == 0 }; val eight = b.count { it.kind == 3 }
        val solids = b.count { it.kind == 1 }; val stripes = b.count { it.kind == 2 }
        s += if (cue == 1) 3f else -3f
        if (eight > 1) s -= 4f * (eight - 1)
        if (solids > 7) s -= 2f * (solids - 7)
        if (stripes > 7) s -= 2f * (stripes - 7)
        return s
    }
}
