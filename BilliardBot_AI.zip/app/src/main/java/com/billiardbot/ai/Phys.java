package com.billiardbot.ai;

import java.util.Arrays;

/**
 * 2-D billiards engine v2 (event based, constant rolling friction, no spin).
 * Same geometry convention as the old Sim.kt: the table rectangle is the area where BALL CENTRES can go,
 * pockets sit one radius outside the corners / sides. New: every physical constant lives in [Params] so a whole
 * ensemble of slightly different "worlds" can be simulated, and cushion restitution depends on impact speed.
 */
public final class Phys {
    private Phys() {}

    static final float VREF = 55f;

    /** Pocket order is fixed: 0 TL, 1 TR, 2 BL, 3 BR, 4 ML, 5 MR (same as Geo.pockets in Planner.kt). */
    public static final class Table {
        public final float il, it, ir, ib, rad, diag, cy;
        public final float[] pkx = new float[6], pky = new float[6], pax = new float[6], pay = new float[6];
        public final boolean[] side = new boolean[6];

        public Table(float l, float t, float r, float b, float rad) {
            il = l; it = t; ir = r; ib = b; this.rad = rad;
            cy = (t + b) / 2f;
            diag = (float) Math.hypot(r - l, b - t);
            float s = (float) Math.sqrt(0.5);
            set(0, l - rad, t - rad, -s, -s, false);
            set(1, r + rad, t - rad, s, -s, false);
            set(2, l - rad, b + rad, -s, s, false);
            set(3, r + rad, b + rad, s, s, false);
            set(4, l - rad, cy, -1f, 0f, true);
            set(5, r + rad, cy, 1f, 0f, true);
        }

        private void set(int i, float x, float y, float ax, float ay, boolean sd) {
            pkx[i] = x; pky[i] = y; pax[i] = ax; pay[i] = ay; side[i] = sd;
        }
    }

    public static final class Params {
        public float pocket = 1f;     // pocket capture radius multiplier
        public float rest = 1f;       // cushion restitution multiplier
        public float powerK = 1f;     // travel distance multiplier (power bar -> distance)
        public float ballRest = 0.96f;
    }

    /** Growable list of points. */
    public static final class Trace {
        public float[] xy = new float[32];
        public int n;
        void add(float x, float y) {
            if (2 * n + 2 > xy.length) xy = Arrays.copyOf(xy, xy.length * 2);
            xy[2 * n] = x; xy[2 * n + 1] = y; n++;
        }
        public float x(int i) { return xy[2 * i]; }
        public float y(int i) { return xy[2 * i + 1]; }
    }

    public static final class Out {
        public int n, first = -1, cuePreCount, npk, cueRailsBefore;
        public float fcx, fcy;
        public boolean cueScratch, railAfter;
        public int[] pk, pki, src, hits, rails;
        public float[] pke, fx, fy;
        public boolean[] alive;
        public Trace[] trace;
    }

    /** Distance (px) the cue ball would roll with no collisions at this power-bar fraction. */
    public static float travel(Table g, float ps, float power) {
        float k = (power - 0.2f) / (0.8f * ps);
        return Math.max(0.03f, k) * 1.1f * g.diag;
    }

    public static Out run(Table g, Params pr, float ps, float cx, float cy, float[] ox, float[] oy,
                          float angle, float power, boolean doTrace, boolean quick) {
        final int n = ox.length + 1;
        final float r = g.rad;
        final float d2 = 4f * r * r;
        final float prC = 1.6f * r * pr.pocket, prS = 1.3f * r * pr.pocket;
        final float FR = 1f, RB = pr.ballRest;
        final float il = g.il, ir = g.ir, it = g.it, ib = g.ib;
        float[] x = new float[n], y = new float[n], vx = new float[n], vy = new float[n];
        boolean[] alive = new boolean[n];
        Arrays.fill(alive, true);
        x[0] = cx; y[0] = cy;
        for (int i = 1; i < n; i++) { x[i] = ox[i - 1]; y[i] = oy[i - 1]; }
        float v0 = (float) Math.sqrt(2f * FR * travel(g, ps, power) * pr.powerK);
        vx[0] = (float) Math.cos(angle) * v0; vy[0] = (float) Math.sin(angle) * v0;

        int[] src = new int[n]; Arrays.fill(src, -1);
        int[] hits = new int[n], rails = new int[n];
        int first = -1, cuePre = -1, cueRailsBefore = 0, npk = 0;
        float fcx = 0, fcy = 0;
        boolean railAfter = false, scratch = false;
        int[] pk = new int[n], pki = new int[n]; float[] pke = new float[n];
        Trace[] tr = null;
        if (doTrace) { tr = new Trace[n]; for (int i = 0; i < n; i++) { tr[i] = new Trace(); tr[i].add(x[i], y[i]); } }

        int steps = 0; boolean done = false;
        while (steps < 3000 && !done) {
            steps++;
            float vmax = 0f;
            for (int i = 0; i < n; i++) if (alive[i]) {
                float s = (float) Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]);
                if (s > vmax) vmax = s;
            }
            if (vmax < 0.01f) break;
            float dt = Math.min(0.08f, 0.35f * r / vmax);
            float rem = dt;
            int guard = 0;
            while (rem > 1e-7f && guard < 40 && !done) {
                guard++;
                float bt = rem; int kind = 0, ei = -1, ej = -1;
                for (int i = 0; i < n; i++) {
                    if (!alive[i]) continue;
                    boolean mi = vx[i] != 0f || vy[i] != 0f;
                    if (mi) {
                        if (vx[i] < 0f) { float t = Math.max(0f, (il - x[i]) / vx[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 0; } }
                        else if (vx[i] > 0f) { float t = Math.max(0f, (ir - x[i]) / vx[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 1; } }
                        if (vy[i] < 0f) { float t = Math.max(0f, (it - y[i]) / vy[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 2; } }
                        else if (vy[i] > 0f) { float t = Math.max(0f, (ib - y[i]) / vy[i]); if (t < bt) { bt = t; kind = 2; ei = i; ej = 3; } }
                        float sp = vx[i] * vx[i] + vy[i] * vy[i];
                        for (int q = 0; q < 6; q++) {
                            float pRad = g.side[q] ? prS : prC;
                            float dx = x[i] - g.pkx[q], dy = y[i] - g.pky[q];
                            float c0 = dx * dx + dy * dy - pRad * pRad;
                            float b = dx * vx[i] + dy * vy[i];
                            float t = -1f;
                            if (c0 <= 0f) t = 0f;
                            else if (b < 0f) { float disc = b * b - sp * c0; if (disc >= 0f) t = (-b - (float) Math.sqrt(disc)) / sp; }
                            if (t >= 0f && t < bt) { bt = t; kind = 3; ei = i; ej = q; }
                        }
                    }
                    for (int j = i + 1; j < n; j++) {
                        if (!alive[j]) continue;
                        boolean mj = vx[j] != 0f || vy[j] != 0f;
                        if (!mi && !mj) continue;
                        float dx = x[j] - x[i], dy = y[j] - y[i];
                        float wx = vx[j] - vx[i], wy = vy[j] - vy[i];
                        float a = wx * wx + wy * wy;
                        if (a < 1e-9f) continue;
                        float b = dx * wx + dy * wy;
                        if (b >= 0f) continue;
                        float c = dx * dx + dy * dy - d2;
                        float t;
                        if (c <= 0f) t = 0f;
                        else { float disc = b * b - a * c; if (disc < 0f) continue; t = (-b - (float) Math.sqrt(disc)) / a; }
                        if (t < bt) { bt = t; kind = 1; ei = i; ej = j; }
                    }
                }
                if (bt > 0f) for (int i = 0; i < n; i++) if (alive[i]) { x[i] += vx[i] * bt; y[i] += vy[i] * bt; }
                rem -= bt;
                if (kind == 1) {
                    int i = ei, j = ej;
                    float dx = x[j] - x[i], dy = y[j] - y[i];
                    float dist = Math.max(1e-4f, (float) Math.hypot(dx, dy));
                    float nx = dx / dist, ny = dy / dist;
                    if (dist < 2f * r) { float push = (2f * r - dist) / 2f; x[i] -= nx * push; y[i] -= ny * push; x[j] += nx * push; y[j] += ny * push; }
                    boolean mi = vx[i] != 0f || vy[i] != 0f, mj = vx[j] != 0f || vy[j] != 0f;
                    float vn = (vx[i] - vx[j]) * nx + (vy[i] - vy[j]) * ny;
                    if (vn > 0f) {
                        float imp = (1f + RB) * 0.5f * vn;
                        vx[i] -= imp * nx; vy[i] -= imp * ny; vx[j] += imp * nx; vy[j] += imp * ny;
                        if (mi) hits[i]++;
                        if (mj) hits[j]++;
                        if (!mi && src[i] < 0) src[i] = j;
                        if (!mj && src[j] < 0) src[j] = i;
                        if (first < 0 && (i == 0 || j == 0)) { first = (i == 0) ? j : i; fcx = x[0]; fcy = y[0]; }
                    }
                    if (tr != null) { tr[i].add(x[i], y[i]); tr[j].add(x[j], y[j]); if (cuePre < 0 && first >= 0) cuePre = tr[0].n; }
                } else if (kind == 2) {
                    int i = ei;
                    float vn;
                    switch (ej) {
                        case 0: vn = -vx[i]; x[i] = il; vx[i] = vn * e(pr, vn); break;
                        case 1: vn = vx[i]; x[i] = ir; vx[i] = -vn * e(pr, vn); break;
                        case 2: vn = -vy[i]; y[i] = it; vy[i] = vn * e(pr, vn); break;
                        default: vn = vy[i]; y[i] = ib; vy[i] = -vn * e(pr, vn); break;
                    }
                    rails[i]++;
                    if (first >= 0) railAfter = true;
                    else if (i == 0) cueRailsBefore++;
                    if (tr != null) tr[i].add(x[i], y[i]);
                } else if (kind == 3) {
                    int i = ei, q = ej;
                    float sp = (float) Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]);
                    float ent = sp < 1e-4f ? 1f : (vx[i] * g.pax[q] + vy[i] * g.pay[q]) / sp;
                    alive[i] = false; vx[i] = 0f; vy[i] = 0f;
                    if (first >= 0) railAfter = true;
                    if (i == 0) scratch = true;
                    else { pk[npk] = i; pki[npk] = q; pke[npk] = ent; npk++; if (quick && first >= 0) done = true; }
                    if (tr != null) tr[i].add(g.pkx[q], g.pky[q]);
                }
            }
            if (done) break;
            if (rem > 1e-7f) for (int i = 0; i < n; i++) if (alive[i]) { x[i] += vx[i] * rem; y[i] += vy[i] * rem; }
            float dv = FR * dt;
            for (int i = 0; i < n; i++) {
                if (!alive[i]) continue;
                float s = (float) Math.sqrt(vx[i] * vx[i] + vy[i] * vy[i]);
                if (s == 0f) continue;
                float ns = s - dv;
                if (ns <= 0f) { vx[i] = 0f; vy[i] = 0f; } else { float k = ns / s; vx[i] *= k; vy[i] *= k; }
            }
        }
        if (tr != null) for (int i = 0; i < n; i++) if (alive[i]) {
            Trace t = tr[i];
            if (Math.hypot(t.x(t.n - 1) - x[i], t.y(t.n - 1) - y[i]) > 0.5) t.add(x[i], y[i]);
        }
        if (cuePre < 0) cuePre = tr != null ? tr[0].n : 0;
        Out o = new Out();
        o.n = n; o.first = first; o.fcx = fcx; o.fcy = fcy; o.cuePreCount = cuePre; o.cueScratch = scratch;
        o.railAfter = railAfter; o.npk = npk; o.pk = pk; o.pki = pki; o.pke = pke; o.src = src; o.hits = hits;
        o.rails = rails; o.cueRailsBefore = cueRailsBefore; o.fx = x; o.fy = y; o.alive = alive; o.trace = tr;
        return o;
    }

    /** Cushion restitution: livelier for slow impacts, deader for hard ones. */
    private static float e(Params p, float vn) {
        float k = vn / VREF; if (k > 1f) k = 1f; if (k < 0f) k = 0f;
        return p.rest * (0.88f - 0.16f * k);
    }
}
