package com.billiardbot.ai;

import java.util.*;
import java.util.concurrent.*;

/**
 * Shot planner v2: "ensemble + Monte-Carlo" instead of hard geometric gates.
 *
 *  1. Candidate aims: geometric seeds (direct / bank 1-2 cushions / kick / combo / kiss) PLUS a dense angle sweep
 *     (always in trick mode) so shots the geometry formulas miss are still found by the physics engine itself.
 *  2. Every candidate is simulated under many slightly different "worlds" (aim error, power error, detection jitter of
 *     every ball, pocket size, cushion bounce, power-to-distance) -> probability of success + expected value.
 *  3. The aim angle is moved to the middle of the real working window, fouls / scratches / leaving the opponent a shot
 *     all cost points, and the best few get a 2-ply look-ahead (how good is the NEXT shot from where everything stops).
 *  4. Everything runs on a thread pool and respects a time budget.
 */
public final class Brain {
    private Brain() {}

    public static final int T_DIRECT = 0, T_BANK = 1, T_KISS = 2, T_COMBO = 3, T_KICK = 4, T_SAFE = 5;
    private static final float[] POWERS = {0.35f, 0.45f, 0.55f, 0.65f, 0.8f, 1f};
    private static final float[] SAFE_POWERS = {0.35f, 0.5f, 0.65f};
    private static final float STEP = (float) Math.toRadians(0.045);
    private static final float TWO_PI = (float) (2 * Math.PI);

    public static final class Shot {
        public float angle, power, prob, tolDeg, score;
        public int type, mainKind = -1, pocket = -1, ownN;
        public boolean safe, hasBall;
        public float ghx, ghy, bx, by;
        public final ArrayList<float[]> cuePre = new ArrayList<>(), cuePost = new ArrayList<>(),
                legs = new ArrayList<>(), extra = new ArrayList<>(), helper = new ArrayList<>(), marks = new ArrayList<>();
    }

    // ---------------------------------------------------------------------------------------------- context

    private static final class Ctx {
        final Phys.Table g; final float ps, cx, cy; final float[] ox, oy; final int[] kind; final int mode, ownLeft;
        final Phys.Params nominal = new Phys.Params();
        Ctx(Phys.Table g, float ps, float cx, float cy, float[] ox, float[] oy, int[] kind, int mode) {
            this.g = g; this.ps = ps; this.cx = cx; this.cy = cy; this.ox = ox; this.oy = oy; this.kind = kind; this.mode = mode;
            int c = 0; for (int k : kind) if (ownK(mode, k)) c++;
            ownLeft = c;
        }
        static boolean ownK(int mode, int k) { return mode == 0 ? k == 1 : mode == 1 ? k == 2 : (k == 1 || k == 2); }
        boolean own(int k) { return ownK(mode, k); }
        boolean legalFirst(int k) { return ownLeft > 0 ? own(k) : k == 3; }
        int kindOf(int i) { return kind[i - 1]; }
    }

    /** One random "world". */
    private static final class Smp {
        float dAng, jcx, jcy; float[] jx, jy; Phys.Params p = new Phys.Params();
    }

    private static Smp[] samples(int k, int n, float rad, long seed) {
        Random rnd = new Random(seed);
        Smp[] out = new Smp[k];
        float sa = (float) Math.toRadians(0.07);
        for (int i = 0; i < k; i++) {
            Smp s = new Smp();
            s.dAng = (float) rnd.nextGaussian() * sa;
            s.jcx = (float) rnd.nextGaussian() * 0.07f * rad; s.jcy = (float) rnd.nextGaussian() * 0.07f * rad;
            s.jx = new float[n]; s.jy = new float[n];
            for (int j = 0; j < n; j++) { s.jx[j] = (float) rnd.nextGaussian() * 0.07f * rad; s.jy[j] = (float) rnd.nextGaussian() * 0.07f * rad; }
            s.p.pocket = 0.90f + 0.15f * rnd.nextFloat();
            s.p.rest = 0.93f + 0.14f * rnd.nextFloat();
            s.p.powerK = (0.95f + 0.10f * rnd.nextFloat()) * (1f + 0.04f * (float) rnd.nextGaussian());
            s.p.ballRest = 0.94f + 0.04f * rnd.nextFloat();
            out[i] = s;
        }
        return out;
    }

    private static Phys.Out sim(Ctx c, Smp s, float ang, float power, boolean trace, boolean quick) {
        if (s == null) return Phys.run(c.g, c.nominal, c.ps, c.cx, c.cy, c.ox, c.oy, ang, power, trace, quick);
        int n = c.ox.length;
        float[] ox = new float[n], oy = new float[n];
        for (int i = 0; i < n; i++) { ox[i] = c.ox[i] + s.jx[i]; oy[i] = c.oy[i] + s.jy[i]; }
        return Phys.run(c.g, s.p, c.ps, c.cx + s.jcx, c.cy + s.jcy, ox, oy, ang + s.dAng, power, trace, quick);
    }

    // ---------------------------------------------------------------------------------------------- rules + value

    private static int mainOf(Ctx c, Phys.Out res) {
        if (res.first < 0 || !c.legalFirst(c.kindOf(res.first))) return -1;
        for (int k = 0; k < res.npk; k++) {
            int b = res.pk[k]; int kd = c.kindOf(b);
            if (c.own(kd) || (kd == 3 && c.ownLeft == 0)) return b;
        }
        return -1;
    }

    private static int classify(Phys.Out res, int m) {
        if (m < 0) return T_SAFE;
        if (res.src[m] > 0) return T_COMBO;
        if (res.hits[m] > 0) return T_KISS;
        if (res.cueRailsBefore > 0) return T_KICK;
        if (res.rails[m] > 0) return T_BANK;
        return T_DIRECT;
    }

    private static final class Ev { float v, entry = 1f; boolean ok; int main = -1; }

    private static float segDist(float px, float py, float ax, float ay, float bx, float by) {
        float abx = bx - ax, aby = by - ay, l2 = abx * abx + aby * aby;
        if (l2 < 1e-6f) return (float) Math.hypot(px - ax, py - ay);
        float t = ((px - ax) * abx + (py - ay) * aby) / l2;
        t = Math.max(0f, Math.min(1f, t));
        return (float) Math.hypot(px - (ax + abx * t), py - (ay + aby * t));
    }

    /** How easy is the best plain shot from here? (0 = nothing, ~0.8 = easy). Cheap geometric estimate. */
    private static float quality(Phys.Table g, int mode, float cx, float cy, float[] rx, float[] ry, int[] rk, int cnt) {
        boolean anyOwn = false; for (int i = 0; i < cnt; i++) if (Ctx.ownK(mode, rk[i])) { anyOwn = true; break; }
        float best = 0f; boolean any = false;
        float r = g.rad;
        for (int i = 0; i < cnt; i++) {
            boolean tgt = anyOwn ? Ctx.ownK(mode, rk[i]) : rk[i] == 3;
            if (!tgt) continue;
            any = true;
            for (int q = 0; q < 6; q++) {
                float ux = g.pkx[q] - rx[i], uy = g.pky[q] - ry[i];
                float ul = (float) Math.hypot(ux, uy); if (ul < 1e-3f) continue;
                ux /= ul; uy /= ul;
                float ghx = rx[i] - ux * 2 * r, ghy = ry[i] - uy * 2 * r;
                if (ghx < g.il - r || ghx > g.ir + r || ghy < g.it - r || ghy > g.ib + r) continue;
                float dx = ghx - cx, dy = ghy - cy, d1 = (float) Math.hypot(dx, dy);
                if (d1 < 2.5f * r) continue;
                float cos = (dx * ux + dy * uy) / d1;
                if (cos < 0.34f) continue;
                float entry = ux * g.pax[q] + uy * g.pay[q];
                if (entry < 0.5f) continue;
                boolean blocked = false;
                for (int o = 0; o < cnt && !blocked; o++) {
                    if (o == i) continue;
                    if (segDist(rx[o], ry[o], cx, cy, ghx, ghy) < 2 * r - 1.5f) blocked = true;
                    else if (segDist(rx[o], ry[o], rx[i], ry[i], g.pkx[q], g.pky[q]) < 2 * r - 1.5f) blocked = true;
                }
                if (blocked) continue;
                float sc = (float) Math.pow(cos, 1.3) * entry / (1f + (d1 + ul) / (g.diag * 0.9f));
                if (g.side[q]) sc *= 0.9f;
                if (sc > best) best = sc;
            }
        }
        return any ? best : 0.3f;
    }

    private static Ev eval(Ctx c, Phys.Out res, boolean leave, boolean opp) {
        Ev e = new Ev();
        boolean foul = false;
        if (res.first < 0) foul = true;
        else if (!c.legalFirst(c.kindOf(res.first))) foul = true;
        else if (res.npk == 0 && !res.railAfter) foul = true;
        float v = 0f;
        if (res.cueScratch) { foul = true; v -= 3f; }
        if (foul) v -= 1.5f;
        int own = 0, oppN = 0; boolean eight = false; int main = -1; float entry = 1f;
        for (int k = 0; k < res.npk; k++) {
            int b = res.pk[k]; int kd = c.kindOf(b);
            if (kd == 3) { eight = true; if (main < 0) { main = b; entry = res.pke[k]; } }
            else if (c.own(kd)) { own++; if (main < 0 || c.kindOf(main) == 3) { main = b; entry = res.pke[k]; } }
            else oppN++;
        }
        boolean ok;
        if (eight) { if (c.ownLeft == 0 && !foul) { v += 12f; ok = true; } else { v -= 12f; ok = false; } }
        else ok = !foul && own > 0 && oppN == 0;
        v += own; v -= 0.7f * oppN;
        if (ok) {
            if (leave && !eight) {
                float[] rx = new float[res.n], ry = new float[res.n]; int[] rk = new int[res.n]; int cnt = 0;
                for (int i = 1; i < res.n; i++) if (res.alive[i]) { rx[cnt] = res.fx[i]; ry[cnt] = res.fy[i]; rk[cnt] = c.kindOf(i); cnt++; }
                float cpx = Math.max(c.g.il, Math.min(c.g.ir, res.fx[0])), cpy = Math.max(c.g.it, Math.min(c.g.ib, res.fy[0]));
                float l = quality(c.g, c.mode, cpx, cpy, rx, ry, rk, cnt);
                for (int q = 0; q < 6; q++) if (Math.hypot(c.g.pkx[q] - cpx, c.g.pky[q] - cpy) < 2.4f * c.g.rad) l -= 0.25f;
                v += 0.5f * l;
            }
        } else if (!foul) {
            v -= 0.6f;
            if (opp && !res.cueScratch) {
                float[] rx = new float[res.n], ry = new float[res.n]; int[] rk = new int[res.n]; int cnt = 0;
                for (int i = 1; i < res.n; i++) if (res.alive[i]) { rx[cnt] = res.fx[i]; ry[cnt] = res.fy[i]; rk[cnt] = c.kindOf(i); cnt++; }
                float cpx = Math.max(c.g.il, Math.min(c.g.ir, res.fx[0])), cpy = Math.max(c.g.it, Math.min(c.g.ib, res.fy[0]));
                int om = c.mode == 0 ? 1 : c.mode == 1 ? 0 : 2;
                v -= 0.8f * quality(c.g, om, cpx, cpy, rx, ry, rk, cnt);
            } else v -= 0.3f;
        }
        e.v = v; e.ok = ok; e.main = main; e.entry = entry;
        return e;
    }

    // ---------------------------------------------------------------------------------------------- seeds

    private static final class Seed { final float a, pri; Seed(float a, float pri) { this.a = a; this.pri = pri; } }

    private static float[] refl(float x, float y, int w, Phys.Table g) {
        switch (w) {
            case 0: return new float[]{2 * g.il - x, y};
            case 1: return new float[]{2 * g.ir - x, y};
            case 2: return new float[]{x, 2 * g.it - y};
            default: return new float[]{x, 2 * g.ib - y};
        }
    }

    private static boolean wallOk(float ax, float ay, float bx, float by, int w, Phys.Table g) {
        float t;
        switch (w) {
            case 0: t = (g.il - ax) / (bx - ax); break;
            case 1: t = (g.ir - ax) / (bx - ax); break;
            case 2: t = (g.it - ay) / (by - ay); break;
            default: t = (g.ib - ay) / (by - ay); break;
        }
        if (Float.isNaN(t) || t <= 0.03f || t >= 0.97f) return false;
        float hx = ax + (bx - ax) * t, hy = ay + (by - ay) * t;
        return hx >= g.il - 1 && hx <= g.ir + 1 && hy >= g.it - 1 && hy <= g.ib + 1;
    }

    private static int[] targets(Ctx c) {
        ArrayList<Integer> l = new ArrayList<>();
        for (int i = 1; i <= c.kind.length; i++) if (c.ownLeft > 0 ? c.own(c.kindOf(i)) : c.kindOf(i) == 3) l.add(i);
        int[] o = new int[l.size()]; for (int i = 0; i < o.length; i++) o[i] = l.get(i);
        return o;
    }

    private static float[] seeds(Ctx c, int[] tg, boolean trick) {
        Phys.Table g = c.g; float r = g.rad; ArrayList<Seed> raw = new ArrayList<>();
        class Adder { void add(float ax, float ay, float base) {
            float dx = ax - c.cx, dy = ay - c.cy, d = (float) Math.hypot(dx, dy);
            if (d > 1.5f * r) raw.add(new Seed((float) Math.atan2(dy, dx), base + d / g.diag * 0.5f));
        } }
        Adder A = new Adder();
        for (int ti : tg) {
            float bx = c.ox[ti - 1], by = c.oy[ti - 1];
            for (int q = 0; q < 6; q++) {
                float ux = g.pkx[q] - bx, uy = g.pky[q] - by, ul = (float) Math.hypot(ux, uy);
                if (ul < 1e-3f) continue;
                ux /= ul; uy /= ul;
                if (!trick) A.add(bx - ux * 2 * r, by - uy * 2 * r, 0f);
                for (int w = 0; w < 4; w++) {
                    float[] pm = refl(g.pkx[q], g.pky[q], w, g);
                    if (!wallOk(bx, by, pm[0], pm[1], w, g)) continue;
                    float vx = pm[0] - bx, vy = pm[1] - by, vl = (float) Math.hypot(vx, vy); vx /= vl; vy /= vl;
                    A.add(bx - vx * 2 * r, by - vy * 2 * r, trick ? 0.5f : 1f);
                }
                for (int w1 = 0; w1 < 4; w1++) for (int w2 = 0; w2 < 4; w2++) {
                    if (w1 / 2 == w2 / 2) continue;
                    float[] p1 = refl(g.pkx[q], g.pky[q], w2, g); float[] p2 = refl(p1[0], p1[1], w1, g);
                    if (!wallOk(bx, by, p2[0], p2[1], w1, g)) continue;
                    float vx = p2[0] - bx, vy = p2[1] - by, vl = (float) Math.hypot(vx, vy); vx /= vl; vy /= vl;
                    A.add(bx - vx * 2 * r, by - vy * 2 * r, 3f);
                }
                float ghx = bx - ux * 2 * r, ghy = by - uy * 2 * r;
                for (int w = 0; w < 4; w++) {
                    float[] gm = refl(ghx, ghy, w, g);
                    if (wallOk(c.cx, c.cy, gm[0], gm[1], w, g)) A.add(gm[0], gm[1], 2.5f);
                }
            }
        }
        for (int ta : tg) for (int tb : tg) {
            if (ta == tb) continue;
            float ax = c.ox[ta - 1], ay = c.oy[ta - 1], bx = c.ox[tb - 1], by = c.oy[tb - 1];
            for (int q = 0; q < 6; q++) {
                float ux = g.pkx[q] - bx, uy = g.pky[q] - by, ul = (float) Math.hypot(ux, uy);
                if (ul < 1e-3f) continue;
                ux /= ul; uy /= ul;
                float gx = bx - ux * 2 * r, gy = by - uy * 2 * r;
                float dx = gx - ax, dy = gy - ay, dl = (float) Math.hypot(dx, dy);
                if (dl < 0.2f * r) continue;
                dx /= dl; dy /= dl;
                if (dx * ux + dy * uy < 0.3f) continue;
                A.add(ax - dx * 2 * r, ay - dy * 2 * r, trick ? 0.7f : 1.5f);
            }
        }
        for (int tt : tg) {
            float tx = c.ox[tt - 1], ty = c.oy[tt - 1];
            for (int k = 1; k <= c.kind.length; k++) {
                if (k == tt) continue;
                float kx = c.ox[k - 1], ky = c.oy[k - 1];
                for (int q = 0; q < 6; q++) {
                    float dd = (float) Math.hypot(g.pkx[q] - kx, g.pky[q] - ky);
                    if (dd <= 2.1f * r) continue;
                    float ex = (g.pkx[q] - kx) / dd, ey = (g.pky[q] - ky) / dd;
                    float th = (float) Math.acos(2f * r / dd);
                    for (int s = 0; s < 2; s++) {
                        float a = s == 0 ? th : -th, ca = (float) Math.cos(a), sa = (float) Math.sin(a);
                        float tcx = kx + (ex * ca - ey * sa) * 2 * r, tcy = ky + (ex * sa + ey * ca) * 2 * r;
                        float dx = tcx - tx, dy = tcy - ty, dl = (float) Math.hypot(dx, dy);
                        if (dl < 0.2f * r) continue;
                        dx /= dl; dy /= dl;
                        float gx = g.pkx[q] - tcx, gy = g.pky[q] - tcy, gl = (float) Math.hypot(gx, gy);
                        if (gl < 1e-3f) continue;
                        if ((dx * gx + dy * gy) / gl < 0.15f) continue;
                        A.add(tx - dx * 2 * r, ty - dy * 2 * r, trick ? 0.9f : 2f);
                    }
                }
            }
        }
        raw.sort((p, q) -> Float.compare(p.pri, q.pri));
        HashSet<Integer> seen = new HashSet<>(); ArrayList<Float> out = new ArrayList<>();
        for (Seed s : raw) {
            int key = Math.round(s.a * 700f);
            if (seen.contains(key) || seen.contains(key - 1) || seen.contains(key + 1)) continue;
            seen.add(key); out.add(s.a);
        }
        float[] o = new float[out.size()]; for (int i = 0; i < o.length; i++) o[i] = out.get(i);
        return o;
    }

    // ---------------------------------------------------------------------------------------------- thread pool

    private static ExecutorService pool;
    private static synchronized ExecutorService pool() {
        if (pool == null) {
            int n = Math.max(2, Math.min(6, Runtime.getRuntime().availableProcessors()));
            pool = Executors.newFixedThreadPool(n, r -> { Thread t = new Thread(r, "brain"); t.setDaemon(true); return t; });
        }
        return pool;
    }

    private static <T> List<T> par(List<Callable<T>> jobs) throws InterruptedException {
        ArrayList<T> out = new ArrayList<>();
        if (jobs.isEmpty()) return out;
        List<Future<T>> fs = pool().invokeAll(jobs);
        for (Future<T> f : fs) {
            try { T v = f.get(); if (v != null) out.add(v); }
            catch (ExecutionException e) { /* a failed job is simply ignored */ }
            catch (CancellationException e) { }
        }
        return out;
    }

    // ---------------------------------------------------------------------------------------------- planning

    private static final class Surv { final float a, p; final int type, main; Surv(float a, float p, int type, int main) { this.a = a; this.p = p; this.type = type; this.main = main; } }
    private static final class Cand { final float a, p, v; final int type; Cand(float a, float p, float v, int type) { this.a = a; this.p = p; this.v = v; this.type = type; } }
    private static final class Fin { final Shot s; float e; Fin(Shot s, float e) { this.s = s; this.e = e; } }

    private static float angDiff(float a, float b) {
        float d = a - b;
        while (d > Math.PI) d -= TWO_PI;
        while (d < -Math.PI) d += TWO_PI;
        return d;
    }

    private static void addSeg(ArrayList<float[]> l, float ax, float ay, float bx, float by) {
        if (Math.hypot(bx - ax, by - ay) > 1.5) l.add(new float[]{ax, ay, bx, by});
    }

    private static Shot build(Ctx c, float ang, float power, boolean safe, float stx, float sty) {
        Phys.Table g = c.g; float r = g.rad;
        Phys.Out res = sim(c, null, ang, power, true, false);
        Ev ev = eval(c, res, false, false);
        int m = ev.main;
        if (m < 0 && !safe) return null;
        Shot s = new Shot();
        s.angle = ang; s.power = power; s.safe = safe;
        Phys.Trace ct = res.trace[0];
        int k = Math.max(1, Math.min(res.cuePreCount, Math.max(1, ct.n)));
        for (int i = 0; i < k - 1; i++) addSeg(s.cuePre, ct.x(i), ct.y(i), ct.x(i + 1), ct.y(i + 1));
        int cnt = 0;
        for (int i = k - 1; i < ct.n - 1; i++) { if (cnt >= 2) break; addSeg(s.cuePost, ct.x(i), ct.y(i), ct.x(i + 1), ct.y(i + 1)); cnt++; }
        if (res.first >= 0) { s.ghx = res.fcx; s.ghy = res.fcy; }
        else if (ct.n > 1) { s.ghx = ct.x(1); s.ghy = ct.y(1); }
        else { s.ghx = c.cx; s.ghy = c.cy; }
        if (m > 0) {
            Phys.Trace mt = res.trace[m];
            s.hasBall = true; s.bx = mt.x(0); s.by = mt.y(0);
            for (int i = 0; i < mt.n - 1; i++) addSeg(s.legs, mt.x(i), mt.y(i), mt.x(i + 1), mt.y(i + 1));
            for (int i = 1; i < mt.n - 1; i++) if (Math.hypot(mt.x(i) - mt.x(0), mt.y(i) - mt.y(0)) > 1.5) s.marks.add(new float[]{mt.x(i), mt.y(i)});
            for (int q = 0; q < res.npk; q++) if (res.pk[q] == m) s.pocket = res.pki[q];
            s.mainKind = c.kindOf(m);
            s.type = classify(res, m);
            if (s.type == T_BANK && res.rails[m] >= 2) s.marks.add(0, new float[]{-1f, -1f}); // marker: two cushions (stripped by caller)
            if (res.src[m] > 0) { Phys.Trace ht = res.trace[res.src[m]]; if (ht.n >= 2) addSeg(s.helper, ht.x(0), ht.y(0), ht.x(1), ht.y(1)); }
        } else {
            s.type = T_SAFE;
            if (res.first > 0) { s.hasBall = true; s.bx = res.trace[res.first].x(0); s.by = res.trace[res.first].y(0); }
            else if (safe) { s.hasBall = true; s.bx = stx; s.by = sty; }
        }
        for (int i = 1; i < res.n; i++) {
            if (i == m) continue;
            Phys.Trace t = res.trace[i];
            if (t.n < 2) continue;
            int cn = 0;
            for (int j = 0; j < t.n - 1; j++) {
                if (cn >= 2) break;
                if (Math.hypot(t.x(j + 1) - t.x(j), t.y(j + 1) - t.y(j)) > 1.5 * r) { s.extra.add(new float[]{t.x(j), t.y(j), t.x(j + 1), t.y(j + 1)}); cn++; }
            }
        }
        if (safe) s.type = T_SAFE;
        int ownN = 0; for (int q = 0; q < res.npk; q++) if (c.own(c.kindOf(res.pk[q]))) ownN++;
        s.ownN = ownN;
        return s;
    }

    /**
     * @param bx,by,bk  every ball except the cue ball (kind 1 solid, 2 stripe, 3 eight)
     * @param mode      0 = solids, 1 = stripes, 2 = any
     * @param l,t,r,b   rectangle where ball CENTRES can go
     */
    public static List<Shot> plan(float cx, float cy, float[] bx, float[] by, int[] bk, int mode,
                                  float l, float t, float r, float b, float rad, float ps,
                                  boolean trick, long budgetMs) {
        long t0 = System.nanoTime(), dl = t0 + budgetMs * 1_000_000L;
        Phys.Table g = new Phys.Table(l, t, r, b, rad);
        Ctx c = new Ctx(g, ps, cx, cy, bx, by, bk, mode);
        int[] tg = targets(c);
        if (tg.length == 0) return new ArrayList<>();
        try { return inner(c, tg, trick, dl); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); return new ArrayList<>(); }
    }

    private static List<Shot> inner(final Ctx c, int[] tg, final boolean trick, final long dl) throws InterruptedException {
        final int n = c.kind.length;
        // ---- 1) candidate aims that pocket something (nominal world, stops at first fallen ball)
        ArrayList<float[]> jobsA = new ArrayList<>();   // {angle, power, prio}
        float[] geo = seeds(c, tg, trick);
        for (float a : geo) { jobsA.add(new float[]{a, 1f}); jobsA.add(new float[]{a, 0.55f}); }
        final int geoCount = jobsA.size();
        if (trick) addDense(jobsA, 0.15f);

        List<Surv> surv = probe(c, jobsA, trick, dl);
        if (!trick && countGeo(surv, geoCount) < 6 && System.nanoTime() < dl) {
            ArrayList<float[]> dense = new ArrayList<>(); addDense(dense, 0.4f);
            surv.addAll(probe(c, dense, trick, dl));
        }
        // dedupe
        ArrayList<Surv> uniq = new ArrayList<>();
        for (Surv s : surv) {
            boolean dup = false;
            for (Surv u : uniq) if (u.type == s.type && u.main == s.main && Math.abs(angDiff(u.a, s.a)) < 0.0035f) { dup = true; break; }
            if (!dup) uniq.add(s);
            if (uniq.size() >= 140) break;
        }

        // ---- 2) which powers work, and what do they leave?
        List<Callable<List<Cand>>> j2 = new ArrayList<>();
        for (final Surv s : uniq) j2.add(() -> {
            if (System.nanoTime() > dl) return null;
            Cand b1 = null, b2 = null;
            for (float pw : POWERS) {
                Ev ev = eval(c, sim(c, null, s.a, pw, false, false), c, true);
                if (!ev.ok) continue;
                Cand cd = new Cand(s.a, pw, ev.v, s.type);
                if (b1 == null || cd.v > b1.v) { b2 = b1; b1 = cd; } else if (b2 == null || cd.v > b2.v) b2 = cd;
            }
            ArrayList<Cand> o = new ArrayList<>();
            if (b1 != null) o.add(b1);
            if (b2 != null) o.add(b2);
            return o;
        });
        ArrayList<Cand> cands = new ArrayList<>();
        for (List<Cand> l : par(j2)) cands.addAll(l);
        cands.sort((p, q) -> Float.compare(q.v, p.v));
        while (cands.size() > 36) cands.remove(cands.size() - 1);

        // ---- 3) Monte-Carlo refinement: move to the centre of the working window, measure the real success probability
        final Smp[] sweep = samples(8, n, c.g.rad, 1234L);
        final Smp[] fin = samples(32, n, c.g.rad, 98765L);
        List<Callable<Fin>> j3 = new ArrayList<>();
        for (final Cand cd : cands) j3.add(() -> refine(c, cd, sweep, fin, trick, dl));
        ArrayList<Fin> fins = new ArrayList<>(par(j3));

        // ---- 4) defence
        if (!trick || fins.isEmpty()) {
            Fin bestSafe = null;
            for (int ti : tg) {
                if (System.nanoTime() > dl) break;
                float dx = c.ox[ti - 1] - c.cx, dy = c.oy[ti - 1] - c.cy, dist = (float) Math.hypot(dx, dy);
                if (dist < 2.5f * c.g.rad) continue;
                float base = (float) Math.atan2(dy, dx);
                float off = (float) Math.asin(Math.max(0f, Math.min(0.9f, 0.9f * c.g.rad / dist)));
                for (float da : new float[]{0f, off, -off}) for (float pw : SAFE_POWERS) {
                    Phys.Out res = sim(c, null, base + da, pw, false, false);
                    Ev ev = eval(c, res, false, true);
                    if (res.first < 0 || res.cueScratch || res.npk > 0) continue;
                    if (bestSafe == null || ev.v > bestSafe.e) {
                        Shot sh = build(c, base + da, pw, true, c.ox[ti - 1], c.oy[ti - 1]);
                        if (sh != null) { sh.prob = 1f; bestSafe = new Fin(sh, ev.v); }
                    }
                }
            }
            if (bestSafe != null) fins.add(bestSafe);
        }

        // ---- 5) two-ply look-ahead for the best few
        fins.sort((p, q) -> Float.compare(q.e, p.e));
        final int top = Math.min(6, fins.size());
        List<Callable<float[]>> j5 = new ArrayList<>();
        for (int i = 0; i < top; i++) {
            final int idx = i; final Fin f = fins.get(i);
            if (f.s.safe || f.s.mainKind == 3) continue;
            j5.add(() -> {
                if (System.nanoTime() > dl) return null;
                Phys.Out res = sim(c, null, f.s.angle, f.s.power, false, false);
                float nx = quickNext(c, res);
                return new float[]{idx, nx};
            });
        }
        for (float[] r : par(j5)) { Fin f = fins.get((int) r[0]); f.e += 0.6f * f.s.prob * r[1]; }
        fins.sort((p, q) -> Float.compare(q.e, p.e));

        ArrayList<Shot> out = new ArrayList<>();
        for (Fin f : fins) {
            if (out.size() >= 6) break;
            boolean dup = false;
            for (Shot a : out) if (Math.abs(angDiff(a.angle, f.s.angle)) < 0.017f) { dup = true; break; }
            if (dup) continue;
            f.s.score = f.e;
            out.add(f.s);
        }
        return out;
    }

    private static void addDense(ArrayList<float[]> jobs, float stepDeg) {
        float step = (float) Math.toRadians(stepDeg);
        for (float a = -(float) Math.PI; a < Math.PI; a += step) { jobs.add(new float[]{a, 0.85f}); jobs.add(new float[]{a, 0.5f}); }
    }

    private static int countGeo(List<Surv> s, int geoCount) { return s.size(); }

    private static List<Surv> probe(final Ctx c, ArrayList<float[]> jobs, final boolean trick, final long dl) throws InterruptedException {
        // chunk jobs so each task does a batch (less scheduling overhead)
        List<Callable<List<Surv>>> tasks = new ArrayList<>();
        int chunk = 24;
        for (int i = 0; i < jobs.size(); i += chunk) {
            final List<float[]> part = jobs.subList(i, Math.min(jobs.size(), i + chunk));
            tasks.add(() -> {
                ArrayList<Surv> o = new ArrayList<>();
                for (float[] j : part) {
                    if (System.nanoTime() > dl) break;
                    Phys.Out res = sim(c, null, j[0], j[1], false, true);
                    int m = mainOf(c, res);
                    if (m < 0) continue;
                    int tp = classify(res, m);
                    if (trick && tp == T_DIRECT) continue;
                    o.add(new Surv(j[0], j[1], tp, m));
                }
                return o;
            });
        }
        ArrayList<Surv> out = new ArrayList<>();
        for (List<Surv> l : par(tasks)) out.addAll(l);
        return out;
    }

    private static Ev eval(Ctx c, Phys.Out res, Ctx same, boolean leave) { return eval(c, res, leave, false); }

    private static Fin refine(Ctx c, Cand cd, Smp[] sweep, Smp[] fin, boolean trick, long dl) {
        if (System.nanoTime() > dl) return null;
        final int N = 8, W = 2 * N + 1;
        float center = cd.a;
        float[] pOff = new float[W], eOff = new float[W]; boolean[] nomOk = new boolean[W];
        int bi = -1;
        for (int iter = 0; iter < 4; iter++) {
            for (int k = -N; k <= N; k++) {
                float a = center + k * STEP;
                Ev nom = eval(c, sim(c, null, a, cd.p, false, false), false, false);
                nomOk[k + N] = nom.ok;
                float ps = 0, es = 0;
                for (Smp s : sweep) { Ev ev = eval(c, sim(c, s, a, cd.p, false, false), false, false); if (ev.ok) ps++; es += ev.v; }
                pOff[k + N] = ps / sweep.length; eOff[k + N] = es / sweep.length;
            }
            // wide smoothing (+-2 steps): prefers the inside of a plateau over its edge
            bi = -1; float be = -1e9f;
            for (int i = 0; i < W; i++) {
                if (!nomOk[i]) continue;
                float sum = 0, wt = 0;
                for (int d = -2; d <= 2; d++) { int j = i + d; if (j < 0 || j >= W) { sum += -2f * (3 - Math.abs(d)); wt += 3 - Math.abs(d); continue; } float w = 3 - Math.abs(d); sum += w * eOff[j]; wt += w; }
                float e = sum / wt;
                if (e > be) { be = e; bi = i; }
            }
            if (bi < 0) return null;
            if ((bi <= 1 || bi >= W - 2) && iter < 3) { center = center + (bi - N) * STEP; continue; }
            break;
        }
        float ang = center + (bi - N) * STEP;
        int lo = bi, hi = bi;
        while (lo > 0 && pOff[lo - 1] >= 0.5f) lo--;
        while (hi < W - 1 && pOff[hi + 1] >= 0.5f) hi++;
        float tolDeg = (hi - lo + 1) * 0.045f / 2f;
        float ps = 0, es = 0; float entrySum = 0; int entryN = 0;
        for (Smp s : fin) {
            Ev ev = eval(c, sim(c, s, ang, cd.p, false, false), true, false);
            if (ev.ok) { ps++; entrySum += ev.entry; entryN++; }
            es += ev.v;
        }
        float prob = ps / fin.length;
        if (prob < (trick ? 0.05f : 0.10f)) return null;
        float entry = entryN > 0 ? Math.max(0f, entrySum / entryN) : 0.5f;
        Shot sh = build(c, ang, cd.p, false, 0, 0);
        if (sh == null) return null;
        if (trick && sh.type == T_DIRECT) return null;
        sh.prob = prob;
        sh.tolDeg = tolDeg * Math.min(1f, 0.4f + entry);
        return new Fin(sh, es / fin.length);
    }

    /** How good is the best direct shot from where this shot leaves everything? 0..1 */
    private static float quickNext(Ctx c, Phys.Out res) {
        int cnt = 0; int n = res.n;
        float[] rx = new float[n], ry = new float[n]; int[] rk = new int[n];
        for (int i = 1; i < n; i++) if (res.alive[i]) { rx[cnt] = res.fx[i]; ry[cnt] = res.fy[i]; rk[cnt] = c.kindOf(i); cnt++; }
        if (cnt == 0) return 0f;
        float cpx = Math.max(c.g.il, Math.min(c.g.ir, res.fx[0])), cpy = Math.max(c.g.it, Math.min(c.g.ib, res.fy[0]));
        Ctx nc = new Ctx(c.g, c.ps, cpx, cpy, Arrays.copyOf(rx, cnt), Arrays.copyOf(ry, cnt), Arrays.copyOf(rk, cnt), c.mode);
        int[] tg = targets(nc);
        Smp[] sm = samples(4, cnt, c.g.rad, 777L);
        float best = 0f; float r = c.g.rad;
        for (int ti : tg) for (int q = 0; q < 6; q++) {
            float bx = nc.ox[ti - 1], by = nc.oy[ti - 1];
            float ux = c.g.pkx[q] - bx, uy = c.g.pky[q] - by, ul = (float) Math.hypot(ux, uy);
            if (ul < 1e-3f) continue;
            ux /= ul; uy /= ul;
            float gx = bx - ux * 2 * r, gy = by - uy * 2 * r;
            float dx = gx - cpx, dy = gy - cpy, dl2 = (float) Math.hypot(dx, dy);
            if (dl2 < 2.5f * r) continue;
            if ((dx * ux + dy * uy) / dl2 < 0.3f) continue;
            float a = (float) Math.atan2(dy, dx);
            Ev e0 = eval(nc, sim(nc, null, a, 0.6f, false, false), false, false);
            if (!e0.ok) continue;
            float okc = 0;
            for (Smp s : sm) if (eval(nc, sim(nc, s, a, 0.6f, false, false), false, false).ok) okc++;
            float p = okc / sm.length;
            if (p > best) best = p;
            if (best >= 1f) return 1f;
        }
        return best;
    }
}
