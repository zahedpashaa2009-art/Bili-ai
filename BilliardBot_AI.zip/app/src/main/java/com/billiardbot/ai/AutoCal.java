package com.billiardbot.ai;

import java.util.*;

/**
 * Automatic calibration from ONE screenshot (no taps):
 *  - table: dominant saturated hue = cloth -> largest connected blob -> its bounds
 *  - ball radius: Hough radius sweep over the table (the radius whose circle votes pile up sharpest)
 *  - power bar: tall, thin, saturated vertical strip beside the table (best effort, may be "not found")
 * Output rectangle = area where ball CENTRES can go (cloth edge moved in by one ball radius), same as manual calibration.
 */
public final class AutoCal {
    private AutoCal() {}

    public static final class Result {
        public boolean ok, powerFound;
        public float l, t, r, b, ball;
        public float ptx, pty, pbx, pby;   // power bar: top = minimum power, bottom = maximum power
        public String note = "";
    }

    /** radius / cloth width (derived from the ratio the manual calibration used: ball = 0.0301 * centre-area width) */
    private static final float R_RATIO = 0.0301f / (1f + 2f * 0.0301f);

    private static float[] hsv(int c) {
        float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
        float mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b)), d = mx - mn;
        float h = 0;
        if (d > 1e-6f) {
            if (mx == r) h = 60f * (((g - b) / d) % 6f);
            else if (mx == g) h = 60f * ((b - r) / d + 2f);
            else h = 60f * ((r - g) / d + 4f);
            if (h < 0) h += 360f;
        }
        return new float[]{h, mx <= 0 ? 0 : d / mx, mx};
    }

    private static float hdiff(float a, float b) { float d = Math.abs(a - b) % 360f; return d > 180f ? 360f - d : d; }

    public static Result run(int[] px, int w, int h, int stride) {
        Result res = new Result();
        final int S = 3;
        final int gw = w / S, gh = h / S;
        if (gw < 50 || gh < 50) { res.note = "image too small"; return res; }
        float[] H = new float[gw * gh], Sa = new float[gw * gh], V = new float[gw * gh];
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
            float[] f = hsv(px[(y * S) * stride + x * S]);
            int i = y * gw + x; H[i] = f[0]; Sa[i] = f[1]; V[i] = f[2];
        }
        // 1) dominant hue
        float[] bins = new float[36];
        for (int i = 0; i < H.length; i++) if (Sa[i] > 0.25f && V[i] > 0.2f) bins[(int) (H[i] / 10f) % 36]++;
        float tot = 0; for (float b : bins) tot += b;
        if (tot < H.length * 0.05f) { Arrays.fill(bins, 0); for (int i = 0; i < H.length; i++) if (Sa[i] > 0.12f && V[i] > 0.2f) bins[(int) (H[i] / 10f) % 36]++; }
        int bb = 0; float bs = -1;
        for (int i = 0; i < 36; i++) { float s = bins[i] + 0.5f * (bins[(i + 1) % 36] + bins[(i + 35) % 36]); if (s > bs) { bs = s; bb = i; } }
        float hc = bb * 10f + 5f;
        // 2) cloth colour statistics
        ArrayList<Float> ss = new ArrayList<>(), vs = new ArrayList<>();
        for (int i = 0; i < H.length; i += 2) if (hdiff(H[i], hc) < 18f && Sa[i] > 0.12f && V[i] > 0.2f) { ss.add(Sa[i]); vs.add(V[i]); }
        if (ss.size() < 200) { res.note = "no cloth colour found"; return res; }
        Collections.sort(ss); Collections.sort(vs);
        float sMed = ss.get(ss.size() / 2), vMed = vs.get(vs.size() / 2);
        // refine hue
        double sx = 0, sy = 0; int cn = 0;
        for (int i = 0; i < H.length; i += 2) if (hdiff(H[i], hc) < 18f && Sa[i] > 0.12f && V[i] > 0.2f && Math.abs(V[i] - vMed) < 0.25f) { sx += Math.cos(Math.toRadians(H[i])); sy += Math.sin(Math.toRadians(H[i])); cn++; }
        if (cn > 0) hc = (float) ((Math.toDegrees(Math.atan2(sy, sx)) + 360) % 360);
        boolean[] mask = new boolean[gw * gh];
        for (int i = 0; i < mask.length; i++) mask[i] = hdiff(H[i], hc) < 14f && Sa[i] > 0.55f * sMed && Math.abs(V[i] - vMed) < 0.12f;
        // 3) largest connected blob
        int[] lab = new int[gw * gh]; int best = 0, bestN = 0, cur = 0;
        int[] stack = new int[gw * gh];
        for (int s0 = 0; s0 < mask.length; s0++) {
            if (!mask[s0] || lab[s0] != 0) continue;
            cur++; int sp = 0, cnt = 0; stack[sp++] = s0; lab[s0] = cur;
            while (sp > 0) {
                int i = stack[--sp]; cnt++;
                int x = i % gw, y = i / gw;
                if (x > 0 && mask[i - 1] && lab[i - 1] == 0) { lab[i - 1] = cur; stack[sp++] = i - 1; }
                if (x < gw - 1 && mask[i + 1] && lab[i + 1] == 0) { lab[i + 1] = cur; stack[sp++] = i + 1; }
                if (y > 0 && mask[i - gw] && lab[i - gw] == 0) { lab[i - gw] = cur; stack[sp++] = i - gw; }
                if (y < gh - 1 && mask[i + gw] && lab[i + gw] == 0) { lab[i + gw] = cur; stack[sp++] = i + gw; }
            }
            if (cnt > bestN) { bestN = cnt; best = cur; }
        }
        if (bestN < gw * gh * 0.12f) { res.note = "table blob too small"; return res; }
        int[] rowC = new int[gh], colC = new int[gw]; int rowMax = 0, colMax = 0;
        for (int i = 0; i < lab.length; i++) if (lab[i] == best) { rowC[i / gw]++; colC[i % gw]++; }
        for (int v : rowC) rowMax = Math.max(rowMax, v);
        for (int v : colC) colMax = Math.max(colMax, v);
        int ry0 = -1, ry1 = -1, cx0 = -1, cx1 = -1;
        for (int y = 0; y < gh; y++) if (rowC[y] >= 0.5f * rowMax) { if (ry0 < 0) ry0 = y; ry1 = y; }
        for (int x = 0; x < gw; x++) if (colC[x] >= 0.5f * colMax) { if (cx0 < 0) cx0 = x; cx1 = x; }
        float x0 = cx0 * S, x1 = (cx1 + 1) * S, y0 = ry0 * S, y1 = (ry1 + 1) * S;
        float cw = x1 - x0, chh = y1 - y0;
        float asp = cw / Math.max(1f, chh);
        if (cw < 0.4f * w || asp < 1.4f || asp > 2.5f) { res.note = "table shape not plausible (aspect " + asp + ")"; return res; }

        // 4) ball radius
        float r0 = R_RATIO * cw;
        float rr = refineRadius(px, w, h, stride, x0, y0, x1, y1, r0);
        res.ball = rr;
        res.l = x0 + rr; res.r = x1 - rr; res.t = y0 + rr; res.b = y1 - rr;
        res.ok = res.r - res.l > 100 && res.b - res.t > 100;
        res.note = String.format("cloth %.0f,%.0f-%.0f,%.0f hue %.0f r0=%.1f r=%.1f", x0, y0, x1, y1, hc, r0, rr);

        // 5) power bar
        findPowerBar(px, w, h, stride, x0, y0, x1, y1, res);
        return res;
    }

    private static float refineRadius(int[] px, int w, int h, int stride, float x0, float y0, float x1, float y1, float r0) {
        final int D = 2;
        int ax0 = (int) (x0 + 0.8f * r0) / D, ay0 = (int) (y0 + 0.8f * r0) / D, ax1 = (int) (x1 - 0.8f * r0) / D, ay1 = (int) (y1 - 0.8f * r0) / D;
        ax0 = Math.max(2, ax0); ay0 = Math.max(2, ay0); ax1 = Math.min(w / D - 3, ax1); ay1 = Math.min(h / D - 3, ay1);
        int gw = ax1 - ax0 + 1, gh = ay1 - ay0 + 1;
        if (gw < 50 || gh < 50) return r0;
        float[] g = new float[gw * gh];
        for (int y = 0; y < gh; y++) for (int x = 0; x < gw; x++) {
            int c = px[((ay0 + y) * D) * stride + (ax0 + x) * D];
            g[y * gw + x] = (((c >> 16) & 255) + ((c >> 8) & 255) + (c & 255)) / 3f;
        }
        int n = 0; int[] ex = new int[gw * gh / 4 + 16], ey = new int[ex.length]; float[] ux = new float[ex.length], uy = new float[ex.length];
        for (int y = 1; y < gh - 1; y++) for (int x = 1; x < gw - 1; x++) {
            int i = y * gw + x;
            float gx = (g[i - gw + 1] + 2 * g[i + 1] + g[i + gw + 1] - g[i - gw - 1] - 2 * g[i - 1] - g[i + gw - 1]) / 8f;
            float gy = (g[i + gw - 1] + 2 * g[i + gw] + g[i + gw + 1] - g[i - gw - 1] - 2 * g[i - gw] - g[i - gw + 1]) / 8f;
            float m = (float) Math.sqrt(gx * gx + gy * gy);
            if (m < 18f || n >= ex.length) continue;
            ex[n] = x; ey[n] = y; ux[n] = gx / m; uy[n] = gy / m; n++;
        }
        if (n < 200) return r0;
        int steps = 13; float bestS = -1, bestR = r0; float[] sc = new float[steps]; float[] rs = new float[steps];
        int[] acc = new int[gw * gh];
        for (int k = 0; k < steps; k++) {
            float r = r0 * (0.80f + 0.4f * k / (steps - 1)); rs[k] = r;
            float rho = r / D;
            Arrays.fill(acc, 0);
            for (int e = 0; e < n; e++) for (int s = -1; s <= 1; s += 2) {
                int vx = Math.round(ex[e] + s * rho * ux[e]), vy = Math.round(ey[e] + s * rho * uy[e]);
                if (vx >= 0 && vx < gw && vy >= 0 && vy < gh) acc[vy * gw + vx]++;
            }
            // 3x3 box sum -> peaks
            int mx = 0; int[] box = new int[gw * gh];
            for (int y = 1; y < gh - 1; y++) for (int x = 1; x < gw - 1; x++) {
                int i = y * gw + x;
                int s = acc[i - gw - 1] + acc[i - gw] + acc[i - gw + 1] + acc[i - 1] + acc[i] + acc[i + 1] + acc[i + gw - 1] + acc[i + gw] + acc[i + gw + 1];
                box[i] = s; if (s > mx) mx = s;
            }
            if (mx == 0) continue;
            ArrayList<int[]> pk = new ArrayList<>();
            for (int i = 0; i < box.length; i++) if (box[i] >= 0.4f * mx) pk.add(new int[]{box[i], i});
            pk.sort((a, b) -> b[0] - a[0]);
            ArrayList<int[]> kept = new ArrayList<>(); float tot = 0;
            for (int[] p : pk) {
                int x = p[1] % gw, y = p[1] / gw; boolean ok = true;
                for (int[] q : kept) { float dx = q[0] - x, dy = q[1] - y; if (dx * dx + dy * dy < 2.25f * rho * rho) { ok = false; break; } }
                if (!ok) continue;
                kept.add(new int[]{x, y}); tot += p[0];
                if (kept.size() >= 14) break;
            }
            sc[k] = tot / rho;
            if (sc[k] > bestS) { bestS = sc[k]; bestR = r; }
        }
        // only trust the sweep if the winner is clearly sharper than the average radius
        float mean = 0; for (float s : sc) mean += s; mean /= steps;
        if (bestS < 1.25f * mean) return r0;
        // parabolic refinement
        int bk = 0; for (int k = 0; k < steps; k++) if (rs[k] == bestR) bk = k;
        if (bk > 0 && bk < steps - 1) {
            float a = sc[bk - 1], b = sc[bk], c = sc[bk + 1], den = a - 2 * b + c;
            if (Math.abs(den) > 1e-6f) bestR += 0.5f * (a - c) / den * (rs[1] - rs[0]);
        }
        return bestR;
    }

    private static void findPowerBar(int[] px, int w, int h, int stride, float x0, float y0, float x1, float y1, Result res) {
        int ya = (int) Math.max(0, y0 - 0.12f * (y1 - y0)), yb = (int) Math.min(h - 1, y1 + 0.12f * (y1 - y0));
        float minRun = 0.35f * (y1 - y0);
        int[] runLen = new int[w], runTop = new int[w], runBot = new int[w];
        for (int x = 0; x < w; x++) {
            if ((x > x0 - 4 && x < x1 + 4)) continue;
            int bestLen = 0, bt = 0, bbm = 0, curS = -1, gap = 0, last = -1;
            for (int y = ya; y <= yb; y++) {
                float[] f = hsv(px[y * stride + x]);
                boolean bar = f[1] > 0.5f && f[2] > 0.5f;
                if (bar) { if (curS < 0) curS = y; last = y; gap = 0; }
                else if (curS >= 0 && ++gap > 3) { if (last - curS > bestLen) { bestLen = last - curS; bt = curS; bbm = last; } curS = -1; }
            }
            if (curS >= 0 && last - curS > bestLen) { bestLen = last - curS; bt = curS; bbm = last; }
            runLen[x] = bestLen; runTop[x] = bt; runBot[x] = bbm;
        }
        // group neighbouring columns
        float bestScore = 0; int gx0 = -1, gx1 = -1;
        int x = 0;
        while (x < w) {
            if (runLen[x] < minRun) { x++; continue; }
            int s = x; while (x < w && runLen[x] >= minRun) x++;
            int e = x - 1, width = e - s + 1;
            if (width < 0.003f * w || width > 0.07f * w) continue;
            float len = 0; for (int k = s; k <= e; k++) len += runLen[k];
            len /= width;
            if (len > bestScore) { bestScore = len; gx0 = s; gx1 = e; }
        }
        if (gx0 < 0) { res.note += "; power bar not found"; return; }
        float t = 0, b = 0; int c = 0;
        for (int k = gx0; k <= gx1; k++) { t += runTop[k]; b += runBot[k]; c++; }
        float cx = (gx0 + gx1) / 2f;
        res.powerFound = true; res.ptx = cx; res.pbx = cx; res.pty = t / c; res.pby = b / c;
    }
}
