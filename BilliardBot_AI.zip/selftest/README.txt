Desktop self-tests for the new Java core (not part of the Android build).
  javac -d out ../app/src/main/java/com/billiardbot/ai/*.java PlannerCheck.java AutoCalCheck.java
  java -cp out PlannerCheck      # reported success probability vs. independent re-simulation
  java -Djava.awt.headless=true -cp out AutoCalCheck   # auto-calibration on synthetic screenshots
