import com.billiardbot.ai.*;
import java.util.*;
public class PlannerCheck {
    static float L=300,T=150,R=1500,B=750,RAD=36;
    static String[] TN={"direct","bank","kiss","combo","kick","safe"};
    static float measure(Brain.Shot s,float cx,float cy,float[] bx,float[] by,int[] bk,int mode){
        Phys.Table g=new Phys.Table(L,T,R,B,RAD); Random rnd=new Random(7); int ok=0,N=300;
        for(int i=0;i<N;i++){
            Phys.Params p=new Phys.Params(); p.pocket=0.9f+0.15f*rnd.nextFloat(); p.rest=0.93f+0.14f*rnd.nextFloat();
            p.powerK=(0.95f+0.1f*rnd.nextFloat())*(1f+0.04f*(float)rnd.nextGaussian()); p.ballRest=0.94f+0.04f*rnd.nextFloat();
            float[] jx=bx.clone(),jy=by.clone();
            for(int j=0;j<jx.length;j++){jx[j]+=rnd.nextGaussian()*2.52; jy[j]+=rnd.nextGaussian()*2.52;}
            Phys.Out o=Phys.run(g,p,1f,cx+(float)rnd.nextGaussian()*2.52f,cy+(float)rnd.nextGaussian()*2.52f,jx,jy,s.angle+(float)(rnd.nextGaussian()*Math.toRadians(0.07)),s.power,false,false);
            boolean own=false,opp=false; for(int k=0;k<o.npk;k++){int kd=bk[o.pk[k]-1]; if(kd==3)opp=true; else if(mode==2||kd==mode+1) own=true; else opp=true;}
            boolean legal=o.first>0&&(bk[o.first-1]==mode+1||mode==2&&bk[o.first-1]<3);
            if(own&&!opp&&!o.cueScratch&&legal) ok++;
        }
        return ok/(float)N;
    }
    static void run(String name,float cx,float cy,float[] bx,float[] by,int[] bk,int mode,boolean trick){
        long t0=System.currentTimeMillis();
        List<Brain.Shot> l=Brain.plan(cx,cy,bx,by,bk,mode,L,T,R,B,RAD,1f,trick,7000);
        System.out.printf("== %s [%s] %d shots %d ms%n",name,trick?"trick":"normal",l.size(),System.currentTimeMillis()-t0);
        for(Brain.Shot s:l){
            String m=s.safe?"-":String.format("%.2f",measure(s,cx,cy,bx,by,bk,mode));
            System.out.printf("   %-6s pk=%d pw=%.2f reportedP=%.2f independentP=%s tol=%.2f score=%.2f%n",TN[s.type],s.pocket,s.power,s.prob,m,s.tolDeg,s.score);
        }
    }
    public static void main(String[] a){
        // easy straight shot: ball 1 lined up with ML pocket
        run("straight",1100,450,new float[]{600,900,1200,1250},new float[]{450,250,650,200},new int[]{1,2,2,3},0,false);
        // random layouts
        Random r=new Random(3);
        for(int k=0;k<3;k++){
            int n=9; float[] bx=new float[n],by=new float[n]; int[] bk=new int[n];
            for(int i=0;i<n;i++){ boolean okp; do{ bx[i]=L+60+r.nextFloat()*(R-L-120); by[i]=T+60+r.nextFloat()*(B-T-120); okp=true; for(int j=0;j<i;j++) if(Math.hypot(bx[i]-bx[j],by[i]-by[j])<90) okp=false; }while(!okp); bk[i]=i<4?1:(i<8?2:3); }
            float cx=L+100+r.nextFloat()*400, cy=T+100+r.nextFloat()*400;
            run("random"+k,cx,cy,bx,by,bk,0,false);
            run("random"+k,cx,cy,bx,by,bk,0,true);
        }
    }
}
