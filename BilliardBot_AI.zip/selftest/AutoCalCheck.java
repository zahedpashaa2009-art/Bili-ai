import com.billiardbot.ai.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.*;

public class AutoCalCheck {
    static int[] px; static int W,H;
    public static void main(String[] a) throws Exception {
        System.setProperty("java.awt.headless","true");
        int[][] sizes={{2000,900},{2400,1080},{1600,720}};
        Color[] cloths={new Color(30,110,190),new Color(25,140,70),new Color(150,40,50)};
        int k=0; int pass=0,total=0;
        for(int[] sz:sizes) for(Color cl:cloths){
            W=sz[0];H=sz[1];
            BufferedImage im=new BufferedImage(W,H,BufferedImage.TYPE_INT_ARGB);
            Graphics2D g=im.createGraphics(); g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(18,22,36)); g.fillRect(0,0,W,H);
            float tw=W*0.62f, th=tw/1.95f; float tx=(W-tw)/2+W*0.03f, ty=(H-th)/2;
            float rail=tw*0.045f;
            g.setColor(new Color(110,65,28)); g.fillRoundRect((int)(tx-rail),(int)(ty-rail),(int)(tw+2*rail),(int)(th+2*rail),30,30);
            g.setColor(cl); g.fillRect((int)tx,(int)ty,(int)tw,(int)th);
            // cushion band darker (same hue)
            float cb=tw*0.02f; Color dark=new Color((int)(cl.getRed()*0.8),(int)(cl.getGreen()*0.8),(int)(cl.getBlue()*0.8));
            g.setColor(dark); g.fillRect((int)tx,(int)ty,(int)tw,(int)cb); g.fillRect((int)tx,(int)(ty+th-cb),(int)tw,(int)cb); g.fillRect((int)tx,(int)ty,(int)cb,(int)th); g.fillRect((int)(tx+tw-cb),(int)ty,(int)cb,(int)th);
            g.setPaint(new RadialGradientPaint(new java.awt.geom.Point2D.Float(tx+tw/2,ty+th/2),tw*0.62f,new float[]{0f,1f},new Color[]{new Color(0,0,0,0),new Color(0,0,0,60)})); g.fillRect((int)tx,(int)ty,(int)tw,(int)th);
            float surfX0=tx+cb, surfY0=ty+cb, surfX1=tx+tw-cb, surfY1=ty+th-cb;
            float r=0.0301f*(surfX1-surfX0-2*0)/(1+2*0.0301f); // truth radius per the ratio used by the tool
            r*=1.0f+0.06f*((k%3)-1); // game radius deviates +-6% from the tool's assumption
            // pockets
            g.setColor(Color.BLACK); float pr=r*1.5f;
            float[][] pk={{surfX0,surfY0},{surfX1,surfY0},{surfX0,surfY1},{surfX1,surfY1},{surfX0,(surfY0+surfY1)/2},{surfX1,(surfY0+surfY1)/2}};
            for(float[] p:pk) g.fill(new java.awt.geom.Ellipse2D.Float(p[0]-pr,p[1]-pr,2*pr,2*pr));
            // balls
            Random rnd=new Random(k);
            Color[] bc={new Color(240,200,20),new Color(30,60,190),new Color(200,30,30),new Color(110,30,140),new Color(240,120,20),new Color(20,130,60),new Color(120,20,30)};
            int nb=14;
            float[][] pos=new float[nb][2];
            for(int i=0;i<nb;i++){ boolean ok; do{ pos[i][0]=surfX0+r+rnd.nextFloat()*(surfX1-surfX0-2*r); pos[i][1]=surfY0+r+rnd.nextFloat()*(surfY1-surfY0-2*r); ok=true; for(int j=0;j<i;j++) if(Math.hypot(pos[i][0]-pos[j][0],pos[i][1]-pos[j][1])<2.2*r) ok=false; for(float[] p:pk) if(Math.hypot(pos[i][0]-p[0],pos[i][1]-p[1])<3*r) ok=false;}while(!ok);}
            for(int i=0;i<nb;i++){
                float bx=pos[i][0],by=pos[i][1];
                g.setColor(new Color(0,0,0,70)); g.fill(new java.awt.geom.Ellipse2D.Float(bx-r+3,by-r+4,2*r,2*r));
                if(i==0){ g.setColor(new Color(245,245,240)); g.fill(new java.awt.geom.Ellipse2D.Float(bx-r,by-r,2*r,2*r)); }
                else if(i<8){ g.setColor(bc[(i-1)%7]); g.fill(new java.awt.geom.Ellipse2D.Float(bx-r,by-r,2*r,2*r)); g.setColor(Color.WHITE); g.fill(new java.awt.geom.Ellipse2D.Float(bx-r*0.45f,by-r*0.45f,r*0.9f,r*0.9f)); }
                else { g.setColor(Color.WHITE); g.fill(new java.awt.geom.Ellipse2D.Float(bx-r,by-r,2*r,2*r)); g.setColor(bc[(i-1)%7]); g.fillRect((int)(bx-r),(int)(by-r*0.5f),(int)(2*r),(int)r); g.setClip(new java.awt.geom.Ellipse2D.Float(bx-r,by-r,2*r,2*r)); g.setClip(null);}
            }
            // power bar left: gradient
            int bxp=(int)(W*0.04f), bw=(int)(W*0.012f)+6; int byt=(int)(ty), byb=(int)(ty+th);
            g.setColor(new Color(40,40,50)); g.fillRect(bxp-4,byt-6,bw+8,byb-byt+12);
            for(int y=byt;y<=byb;y++){ float t=(y-byt)/(float)(byb-byt); g.setColor(Color.getHSBColor(0.33f*(1-t),0.95f,0.95f)); g.fillRect(bxp,y,bw,1); }
            // UI clutter top
            g.setColor(new Color(60,60,80)); g.fillRect(0,0,W,(int)(ty-rail-10));
            g.dispose();
            px=im.getRGB(0,0,W,H,null,0,W);
            long t0=System.currentTimeMillis();
            AutoCal.Result res=AutoCal.run(px,W,H,W);
            long ms=System.currentTimeMillis()-t0;
            float tl=surfX0+r, tt=surfY0+r, trr=surfX1-r, tb=surfY1-r;
            float pxc=bxp+bw/2f;
            boolean okRect=res.ok&&Math.abs(res.l-tl)<0.8*r&&Math.abs(res.r-trr)<0.8*r&&Math.abs(res.t-tt)<0.8*r&&Math.abs(res.b-tb)<0.8*r;
            if(!okRect) System.out.printf("   truth l=%.0f t=%.0f r=%.0f b=%.0f  got l=%.0f t=%.0f r=%.0f b=%.0f%n",tl,tt,trr,tb,res.l,res.t,res.r,res.b);
            boolean okBall=Math.abs(res.ball-r)<0.12*r;
            boolean okPow=res.powerFound&&Math.abs(res.ptx-pxc)<bw&&Math.abs(res.pty-byt)<0.06*th&&Math.abs(res.pby-byb)<0.06*th;
            total++; if(okRect&&okBall&&okPow) pass++;
            System.out.printf("%dx%d cloth=%s  rect:%s ball:%s(true %.1f got %.1f) power:%s  [%d ms] %s%n",W,H,"("+cl.getRed()+","+cl.getGreen()+","+cl.getBlue()+")",okRect,okBall,r,res.ball,okPow,ms,res.ok?"":res.note);
            if(k==0) javax.imageio.ImageIO.write(im,"png",new java.io.File("synth0.png"));
            k++;
        }
        System.out.println("passed "+pass+"/"+total);
    }
}
